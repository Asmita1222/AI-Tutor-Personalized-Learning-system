# AI Tutor: Personalized Learning System

## Overview
The AI Tutor project is an intelligent learning platform that customizes study paths for students based on their current knowledge and predicted mastery levels.  
It uses deep learning techniques for understanding student feedback and convex optimization methods to recommend efficient study plans.

This system generates personalized quizzes, predicts mastery scores from student feedback, recommends study topics based on prerequisites, and suggests optimized study time.

---

## Features
- 🧠 **Mastery Prediction**: Analyze student feedback using Universal Sentence Encoder.
- 🎯 **Topic Recommendation**: Recommend weak topics based on current mastery and prerequisites.
- 📝 **Quiz Generation**: Create AI-powered quizzes dynamically for various topics.
- 🚀 **Study Plan Optimization**: Allocate efficient study hours using convex optimization.
- 📊 **Progress Tracking**: Save and load student progress data automatically.

---

## File Structure
```plaintext
main.py                # Streamlit frontend app
recommendation_ui.py   # UI for topic recommendations
tutor_backend.py       # Backend logic (load/save student progress, recommend topics)
student_data.json      # Sample student data
mastery_predictor.py   # Mastery score prediction using deep learning
convex_optimizer.py    # Convex optimization for study time
quiz_generator.py      # AI-based quiz generator (using Gemini API)
abstract.pdf           # Project abstract for documentation
requirements.txt       # Required Python libraries
